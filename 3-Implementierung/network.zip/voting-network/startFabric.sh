#!/bin/bash
#
# Copyright IBM Corp All Rights Reserved
#
# SPDX-License-Identifier: Apache-2.0
#
# Exit on first error
set -e

# don't rewrite paths for Windows Git Bash users
export MSYS_NO_PATHCONV=1
starttime=$(date +%s)
LANGUAGE=${1:-"golang"}
CC_SRC_PATH=github.com/
CC_VSN=1.9.7
export COMPOSE_PROJECT_NAME=evoting

# clean the keystore
rm -rf ./hfc-key-store

# launch network; create channel and join peer to channel
./start.sh

# Now launch the CLI container in order to install, instantiate chaincode
# and prime the ledger with our 10 cars
docker-compose -f ./docker-compose.yml -p evoting up -d cli

docker exec -e "COMPOSE_PROJECT_NAME=evoting" -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.evote.com/users/Admin@org1.evote.com/msp" cli peer chaincode install -n mycc -v "$CC_VSN" -p "$CC_SRC_PATH" -l "$LANGUAGE"
docker exec -e "COMPOSE_PROJECT_NAME=evoting" -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_ADDRESS=peer1.org1.evote.com:7051" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.evote.com/users/Admin@org1.evote.com/msp" cli peer chaincode install -n mycc -v "$CC_VSN" -p "$CC_SRC_PATH" -l "$LANGUAGE"
docker exec -e "COMPOSE_PROJECT_NAME=evoting" -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_ADDRESS=peer2.org1.evote.com:7051" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.evote.com/users/Admin@org1.evote.com/msp" cli peer chaincode install -n mycc -v "$CC_VSN" -p "$CC_SRC_PATH" -l "$LANGUAGE"
docker exec -e "COMPOSE_PROJECT_NAME=evoting" -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_ADDRESS=peer3.org1.evote.com:7051" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.evote.com/users/Admin@org1.evote.com/msp" cli peer chaincode install -n mycc -v "$CC_VSN" -p "$CC_SRC_PATH" -l "$LANGUAGE"
docker exec -e "COMPOSE_PROJECT_NAME=evoting" -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_ADDRESS=peer4.org1.evote.com:7051" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.evote.com/users/Admin@org1.evote.com/msp" cli peer chaincode install -n mycc -v "$CC_VSN" -p "$CC_SRC_PATH" -l "$LANGUAGE"
docker exec -e "COMPOSE_PROJECT_NAME=evoting" -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_ADDRESS=peer0.org1.evote.com:7051" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.evote.com/users/Admin@org1.evote.com/msp" cli peer chaincode instantiate -o orderer.evote.com:7050 -C mychannel -n mycc -v "$CC_VSN" -c '{"Args":["dummy", "dummy"]}'
