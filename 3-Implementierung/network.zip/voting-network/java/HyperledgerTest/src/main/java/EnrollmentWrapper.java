import org.hyperledger.fabric.sdk.Enrollment;

import java.io.Serializable;

public class EnrollmentWrapper implements Serializable {

    private static final long serialVersionUID = 2701870327845509950L;
    private transient Enrollment enrollment;

    public EnrollmentWrapper(Enrollment enrollment) {
        this.enrollment = enrollment;
    }

    public Enrollment getEnrollment() {
        return enrollment;
    }

    public void setEnrollment(Enrollment enrollment) {
        this.enrollment = enrollment;
    }


}
