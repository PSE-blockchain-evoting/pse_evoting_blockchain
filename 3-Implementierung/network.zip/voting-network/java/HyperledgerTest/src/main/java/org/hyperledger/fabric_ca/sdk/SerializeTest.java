package org.hyperledger.fabric_ca.sdk;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyPair;
import java.util.HashSet;
import java.util.Set;

public class SerializeTest {

    public static void main (String[] args) throws IOException {
        AppUser user = new AppUser();
        user.setAccount("teas");
        user.setAffiliation("as");
        user.setMspId("asdui");
        user.setName("akjdha");
        Set<String> set = new HashSet<String>();
        set.add("test");
        user.setRoles(set);
        HFCAEnrollment enrollment = new HFCAEnrollment(new KeyPair(null, null), "sadhsad");
        user.setEnrollment(enrollment);
        ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(Paths.get("test")));
        oos.writeObject(user);
    }
}
