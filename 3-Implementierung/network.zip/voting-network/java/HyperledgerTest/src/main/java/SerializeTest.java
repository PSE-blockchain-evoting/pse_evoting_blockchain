import org.hyperledger.fabric_ca.sdk.AppUser;
import org.hyperledger.fabric_ca.sdk.HFCAEnrollment;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyPair;
import java.util.HashSet;
import java.util.Set;

public class SerializeTest {

    public static void main (String[] args) throws IOException {
        EnrollmentWrapper wrapper = new EnrollmentWrapper(null);
        ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(Paths.get("test")));
        oos.writeObject(wrapper);
    }
}
