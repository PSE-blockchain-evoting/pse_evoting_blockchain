docker-compose -f ./docker-compose.yml -p evoting down
